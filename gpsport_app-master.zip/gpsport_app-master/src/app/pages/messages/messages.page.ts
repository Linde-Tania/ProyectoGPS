import { Component, NgZone, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AlertController, LoadingController, NavController } from '@ionic/angular';
import { DataService } from '../../services/data.service';
import { Geolocation } from '@capacitor/geolocation';

@Component({
  selector: 'app-messages',
  templateUrl: './messages.page.html',
  styleUrls: ['./messages.page.scss'],
})
export class MessagesPage implements OnInit {

  lat;
  long;
  wait: any;

  mensaje = {
    tipo: '',
    coords: '',
    texto: ''
  }

  customPopoverOptions: any = {
    header: 'Tipos de mensajes disponibles',
    backdropDismiss: false,
    //subHeader: 'Select your hair color',
    //message: 'Only select your dominant hair color'
  };


  constructor(
    private datas: DataService,
    public _loader: LoadingController,
    private ngZone: NgZone,
    private navctrl: NavController,
    private _alert: AlertController) { }

  ngOnInit() {
    this.track();
  }

  async track() {
    const loading = await this._loader.create({
      message: 'Espere..',
      spinner: 'dots',
      mode: 'ios',
    });
    await loading.present();

    try {
      Geolocation.checkPermissions().then(async res => {
        //console.log(res.location);
        if (res.location == 'granted') {

          const coordinates = await Geolocation.getCurrentPosition().then();
          this.ngZone.run(() => {
            this.lat = coordinates.coords.latitude;
            this.long = coordinates.coords.longitude;

            this.mensaje.coords = this.lat + ", " + this.long;

            console.log(this.mensaje.coords);
            this._loader.dismiss();
          })

        }
        else {
          Geolocation.requestPermissions();
          this._loader.dismiss();
          this.navctrl.back();
          this.showAlert('Verifique los permisos de localización del dispositivo e intente nuevamente.');

          
        }
      })
    }
    catch (error) {
      this.showAlert('Verifique los permisos de localización del dispositivo.');
      this._loader.dismiss();
      console.error(error);
    }






  }


  // CheckPermissions() {
  //   Geolocation.checkPermissions().then(res => {
  //     //console.log(res.location);

  //     if (res.location == 'granted') {


  //     }
  //     else {

  //     }
  //   })
  // }

  async ONsummit(formulario: NgForm) {

    let form = formulario.form.value;
    console.log(form)

    const loading = await this._loader.create({
      message: 'Espere..',
      spinner: 'dots',
      mode: 'ios',
    });
    await loading.present();

    this.datas.postMessages(form.tipo, form.coords, form.texto, '1').subscribe(res => {
      if (res == null) {

        this._loader.dismiss();
        this.navctrl.back();
        console.log('Mensaje enviado con éxito.');
        this.showAlert('Mensaje enviado con éxito.');

        this.ClearControls();
      }
      else {
        this.navctrl.back();
        this.showAlert('Error encontrado, intente nuevamente.');
        this._loader.dismiss();
      }

    })

  }

  ClearControls() {
    //this.mensaje.coords = '';
    this.mensaje.tipo = '';
    this.mensaje.texto = '';
  }

  showAlert(msg) {
    let alert = this._alert.create({
      message: msg,
      mode: 'ios',
    });
    alert.then((alert) => alert.present());
  }

}
