import { Component, NgZone, ViewChild } from '@angular/core';
//import { Geolocation } from '@ionic-native/geolocation/ngx';
import { AlertController, AlertOptions, IonToggle, LoadingController, ToastController } from '@ionic/angular';
import { DataService } from 'src/app/services/data.service';
import { Geolocation } from '@capacitor/geolocation';
import { LocationAccuracy } from '@ionic-native/location-accuracy/ngx';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  lat;
  long;
  wait: any;
  noww: any;
  status_gps: boolean;

  @ViewChild(IonToggle) tog: IonToggle;

  UserName: string;
  UserID: string;

  LocStatus: boolean = false;
  notificaciones: any[] = [];
  vehiculos: any[] = [];

  constructor(private toastctrl: ToastController,
    private datas: DataService,
    public _loader: LoadingController,
    private _alert: AlertController,
    public ngZone: NgZone,
    private locationAccuracy: LocationAccuracy,
    //private geo: Geolocation
    //private geo: Geolocation
  ) {



    this.locationAccuracy.canRequest().then((canRequest: boolean) => {

      if(canRequest) {
        // the accuracy option will be ignored by iOS
        this.locationAccuracy.request(this.locationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY).then(
          () => {
            this.presentToast('Localización avanzada activada.');
          },
          error => {
            console.log('Error requesting location permissions', error)
            this.presentToast('Error: '+error);
          }
        );
      }
    
    });


    this.status_gps = false;

    const now = new Date();
    this.noww = now.toLocaleString();

    this.CheckPermissions();

    this.UserName = localStorage.getItem("USER_NAME");
    this.UserID = localStorage.getItem("USER_ID");

    this.datas.getConfigs().subscribe(res => {
      console.log(res.items);
      this.notificaciones.push(...res.items);
    })


    this.datas.getVehiculos().subscribe(res => {
      console.log(res.items);
      this.vehiculos.push(...res.items);
    })


  }

  doRefresh(data) {
    this.datas.getConfigs().subscribe(res => {
      console.log(res.items);
      this.notificaciones = [];
      this.notificaciones.push(...res.items);

      data.target.complete();
    })


    this.datas.getVehiculos().subscribe(res => {
      console.log(res.items);
      this.vehiculos = [];
      this.vehiculos.push(...res.items);
    })
  }


  CheckPermissions() {
    Geolocation.checkPermissions().then(res => {
      //console.log(res.location);

      if (res.location == 'granted') {
        //this.tog.disabled = false;
        console.log('Permisos habilitados.');
      }
      else {
        //this.tog.disabled = true;
        Geolocation.requestPermissions();
      }
    })
  }


  stopTracking() {
    Geolocation.clearWatch({ id: this.wait });
    console.log('traking stop..');
    this.LocStatus = false;
    this.status_gps = false;

  }


  async StartRouteCAP() {

    var listOfObjects = [];
    this.vehiculos.forEach(function (entry) {
      var singleObj = {};
      singleObj['name'] = entry.nombre_vehiculo;
      singleObj['type'] = 'radio';
      singleObj['label'] = entry.nombre_vehiculo;
      singleObj['value'] = entry.id_vehiculo;
      singleObj['cssClass'] = "text-wrap";
      

      if (entry.id_vehiculo == 1) {
        singleObj['checked'] = true;
      }

      listOfObjects.push(singleObj);
    });

    const alert = await this._alert.create({
      cssClass: 'my-custom-class',
      header: 'Iniciar ruta',
      subHeader: 'Selecciona vehículo',
      inputs: listOfObjects,
      buttons: [
        {
          text: 'CANCELAR',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Confirm Cancel');
          }
        }, {
          text: 'ACEPTAR',
          handler: async (data: any) => {
            console.log(data);
            localStorage.setItem("ID_VEHICULO_NOW",data)

            this.LocStatus = true;

            const loading = await this._loader.create({
              message: 'Espere..',
              spinner: 'dots',
              mode: 'ios',
            });
            await loading.present();

            try {

              this.wait = Geolocation.watchPosition({}, (position, err) => {
             

                //debugger
                if (err) {
                  //debugger
                  this.presentToast('No fue posible habilitar el servicio, intenta nuevamente.');
                  console.error(err.message)
                  this.LocStatus = false;
                  this._loader.dismiss();

                }

                //debugger
                if (this.LocStatus && err == undefined && position != null) {
                
                  this.status_gps = true;
                  //this.ngZone.run(() => {
                  //debugger
                  this.lat = position.coords.latitude;
                  this.long = position.coords.longitude;
                  //debugger
                  console.log(position)
                  console.info(this.lat + ", " + this.long);
                  this.presentToast(this.lat + ", " + this.long);

                  
                  this.datas.postRutas(localStorage.getItem("ID_VEHICULO_NOW"), localStorage.getItem("USER_ID"), this.lat + ","+this.long).subscribe(res => {
                    //console.log(res);
                  })
                  // this.datas.postRutas(localStorage.getItem("ID_VEHICULO_NOW"), localStorage.getItem("USER_ID"), this.long + "!3d" + this.lat).subscribe(res => {
                  //   //console.log(res);
                  // })

                  //este comentado....
                  //this._loader.dismiss();
                  //})
                }

              })

              this._loader.dismiss();

              Geolocation.clearWatch({ id: this.wait });
            }
            catch (error) {
              this.showAlert('Verifique los permisos de localización del dispositivo.');
              this._loader.dismiss();
              console.error(error);
            }

          }
        }
      ]
    });

    await alert.present();
  }


  async presentToast(message) {
    const toast = await this.toastctrl.create({
      message: message,
      duration: 2000
    });
    toast.present();
  }

  showAlert(msg) {
    let alert = this._alert.create({
      message: msg,
      mode: 'ios',
    });
    alert.then((alert) => alert.present());
  }

}