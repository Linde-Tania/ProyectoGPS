import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AlertController, LoadingController, NavController, ToastController } from '@ionic/angular';
import { DataService } from '../../services/data.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  constructor(
    private datas:DataService,
    private _loader: LoadingController,
    public navCtrl: NavController,
    private toastctrl: ToastController,
    private _alert: AlertController) 
    { }

  usuario = {
    email:'',
    pass:''
  }

  passwordData: any = {
    showPlainPassword: false,
    inputType: "password",
    iconName: "eye",
  };
  
  ngOnInit() {
  }

  
  async ONsummit(formulario:NgForm){

    const loading = await this._loader.create({
      message: 'Espere..',
      spinner: 'dots',
      mode: 'ios',
    });
    await loading.present();

    let form = formulario.form.value;
    console.log(form)   
  
    this.datas.validaUSUARIO(form.email,form.pass).subscribe(res =>{

      console.log(res.items);
      if(res.items.length == 0)
      {
        this.showAlert('Credenciales no válidas.');
        this._loader.dismiss();
      }
      else if (res.items.length == 1){
        this.presentToast('Autenticación exitosa.');
        this._loader.dismiss();

        localStorage.setItem("USER_NAME",res.items[0].nombre_conductor);
        localStorage.setItem("USER_ID",res.items[0].id_conductor);

        this.datas.postBitacora('INICIO DE SESION','Inicio de sesión para el usuario: '+res.items[0].nombre_conductor).subscribe(res => {
          console.log(res)
        })
        this.navCtrl.navigateRoot(["home"]);
      }
      else{
        this.showAlert('Error desconocido, intente más tarde.');
        this._loader.dismiss();
      }

    })




  }



  toggleShowPlainPassword = () => {
    this.passwordData.showPlainPassword = !this.passwordData.showPlainPassword;
    if (this.passwordData.showPlainPassword) {
      this.passwordData = {
        ...this.passwordData,
        inputType: "text",
        iconName: "eye-off",
      };
    } else {
      this.passwordData = {
        ...this.passwordData,
        inputType: "password",
        iconName: "eye",
      };
    }
  };

  showAlert(msg) {
    let alert = this._alert.create({
      message: msg,
      mode: 'ios',
    });
    alert.then((alert) => alert.present());
  }

  async presentToast(message) {
    const toast = await this.toastctrl.create({
      message: message,
      duration: 2000
    });
    toast.present();
  }


}
