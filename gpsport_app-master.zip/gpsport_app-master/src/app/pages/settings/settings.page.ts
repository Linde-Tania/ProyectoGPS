import { Component, OnInit } from '@angular/core';
import { NavController, AlertController } from '@ionic/angular';
import { Geolocation } from '@capacitor/geolocation';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.page.html',
  styleUrls: ['./settings.page.scss'],
})
export class SettingsPage implements OnInit {

  constructor(private navCtrl:NavController,
              private alertCtrl: AlertController) { }

  ngOnInit() {
  }

  async LogOff() {
    const alert = await this.alertCtrl.create({
      message: '¿Estás seguro de cerrar sesión?',
      mode: 'ios',
      buttons: [
        {
          text: 'Cancelar',
          role: 'cancel',
          cssClass: 'secondary',
          handler: () => {
            console.log('Cancel...');
          }
        }, {
          text: 'Aceptar',
          handler: () => {
            console.log('Cerrando sesión...');
            localStorage.clear();
            this.navCtrl.navigateRoot(["login"]);
          }
        }
      ]
    });
    await alert.present();
  }

  ionViewDidLeave()
  {

  }


}
