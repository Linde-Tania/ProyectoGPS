export interface PData {
  items: Item[];
  hasMore: boolean;
  limit: number;
  offset: number;
  count: number;
  links: Link[];
}

interface Link {
  rel: string;
  href: string;
}

export interface Item {
  id_config: number;
  nombre_config: string;
  desc_config: string;
  estado: number;
}