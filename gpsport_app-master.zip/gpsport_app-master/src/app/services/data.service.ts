import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment.prod';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  url:string = environment.url_service;

  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

  constructor(private http:HttpClient) { 
    console.log('service running now...')
  }

  getConfigs()
  {
    return this.http.get<any>(this.url+'/get_notificaciones'); 
  }

  getVehiculos()
  {
    return this.http.get<any>(this.url+'/get_vehiculos'); 
  }

  postMessages(type,coord,msg,id_conductor)
  {
    let data = {
      "TIPO":type,
      "COORDENADAS":coord,
      "MENSAJE":msg,
      "ID_CONDUCTOR":id_conductor
    }

    return this.http.post<any>(this.url+'/post_mensajes', JSON.stringify(data), this.httpOptions)
  }

  postBitacora(name, desc)
  {
    let data = {
      "NOMBRE_EVENTO":name,
      "DESC_EVENTO":desc,
    }

    return this.http.post<any>(this.url+'/post_bitacoras', JSON.stringify(data), this.httpOptions)
  }

  postRutas(_id_vehiculo, _id_conductor, coords)
  {
    let data = {
      "ID_VEHICULO":_id_vehiculo,
      "ID_CONDUCTOR":_id_conductor,
      "COORDENADAS":coords,
    }

    console.info(data);

    return this.http.post<any>(this.url+'/post_rutas', JSON.stringify(data), this.httpOptions)
  }

  validaUSUARIO(user, pass)
  {
    return this.http.get<any>(this.url+'/valida_usuario/'+user+'/'+pass); 
  }

}
