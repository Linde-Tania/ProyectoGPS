export const environment = {
  production: true,
  //url_service:'https://apex.oracle.com/pls/apex/dess/gpsport/get_configuraciones',
  url_service:'https://apex.oracle.com/pls/apex/dess/gpsport',
  url_map: 'https://www.google.com/maps/search/?api=1&query='
  //https://www.google.com/maps/search/?api=1&query=14.6571264,-90.488832
};
